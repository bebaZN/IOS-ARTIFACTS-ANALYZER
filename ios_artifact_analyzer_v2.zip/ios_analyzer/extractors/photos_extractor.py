"""
photos_extractor.py
Extracts photo metadata and EXIF data (including GPS) from Photos.sqlite
and also reads EXIF directly from image files when available.
"""

import sqlite3
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

try:
    import exifread
    HAS_EXIF = True
except ImportError:
    HAS_EXIF = False

APPLE_EPOCH_OFFSET = 978307200


def apple_ts(ts) -> str:
    if ts is None:
        return "Unknown"
    try:
        ts_unix = float(ts) + APPLE_EPOCH_OFFSET
        return datetime.fromtimestamp(ts_unix, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        return str(ts)


def dms_to_decimal(dms_str: str, ref: str) -> float | None:
    """Convert DMS string from EXIF to decimal degrees."""
    try:
        parts = str(dms_str).strip("[]").split(",")
        degrees = float(parts[0].strip())
        minutes = float(parts[1].strip())
        frac = parts[2].strip().split("/")
        seconds = float(frac[0]) / float(frac[1]) if "/" in parts[2] else float(frac[0])
        decimal = degrees + minutes / 60 + seconds / 3600
        if ref in ("S", "W"):
            decimal = -decimal
        return round(decimal, 6)
    except Exception:
        return None


class PhotosExtractor:
    DOMAIN = "CameraRollDomain"
    PHOTOS_DB = "Media/PhotoData/Photos.sqlite"

    def __init__(self, parser, output_dir: str):
        self.parser = parser
        self.output_dir = Path(output_dir) / "photos"
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def extract(self) -> list:
        db_path = self.parser.get_file(self.DOMAIN, self.PHOTOS_DB)
        if not db_path:
            raise FileNotFoundError("Photos.sqlite not found in backup")

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        cur.execute("""
            SELECT
                ZASSET.ZFILENAME,
                ZASSET.ZDATECREATED,
                ZASSET.ZLATITUDE,
                ZASSET.ZLONGITUDE,
                ZASSET.ZDURATION,
                ZASSET.ZKIND,
                ZASSET.ZUNIFORMTYPEIDENTIFIER,
                ZADDITIONALASSETATTRIBUTES.ZCAMERAMAKE,
                ZADDITIONALASSETATTRIBUTES.ZCAMERAMODEL
            FROM ZASSET
            LEFT JOIN ZADDITIONALASSETATTRIBUTES
                ON ZASSET.ZADDITIONALATTRIBUTES = ZADDITIONALASSETATTRIBUTES.Z_PK
            ORDER BY ZASSET.ZDATECREATED DESC
            LIMIT 300
        """)
        rows = cur.fetchall()
        conn.close()

        records = []
        for r in rows:
            lat = r["ZLATITUDE"]
            lon = r["ZLONGITUDE"]
            has_gps = lat is not None and lon is not None and lat != -180.0
            records.append({
                "filename":  r["ZFILENAME"] or "Unknown",
                "date":      apple_ts(r["ZDATECREATED"]),
                "latitude":  round(float(lat), 6) if has_gps else None,
                "longitude": round(float(lon), 6) if has_gps else None,
                "has_gps":   has_gps,
                "kind":      "Video" if r["ZKIND"] == 1 else "Photo",
                "type":      r["ZUNIFORMTYPEIDENTIFIER"] or "",
                "camera":    f"{r['ZCAMERAMAKE'] or ''} {r['ZCAMERAMODEL'] or ''}".strip() or "Unknown",
            })
        return records

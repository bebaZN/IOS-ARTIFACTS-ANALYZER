"""
backup_parser.py
Parses the iOS backup Manifest.db and Info.plist to locate artifact files.
"""

import os
import plistlib
import sqlite3
import shutil
from pathlib import Path
from datetime import datetime

try:
    from iphone_backup_decrypt import EncryptedBackup, RelativePath, RelativePathsLike
    HAS_DECRYPT = True
except ImportError:
    HAS_DECRYPT = False


class BackupParser:
    def __init__(self, backup_path: str, password: str = None):
        self.backup_path = Path(backup_path)
        self.password = password
        self.manifest_db = None
        self.device_info = {}
        self.file_map = {}          # domain+filename -> absolute path
        self.decrypted_dir = None
        self._encrypted = False

    # ------------------------------------------------------------------
    def parse(self) -> bool:
        manifest_path = self.backup_path / "Manifest.db"
        info_path = self.backup_path / "Info.plist"

        if not manifest_path.exists():
            print(f"    [!] Manifest.db not found at {manifest_path}")
            return False

        # Read device info
        if info_path.exists():
            with open(info_path, "rb") as f:
                info = plistlib.load(f)
            self.device_info = {
                "device_name":   info.get("Display Name", "Unknown"),
                "ios_version":   info.get("Product Version", "Unknown"),
                "serial_number": info.get("Serial Number", "Unknown"),
                "imei":          info.get("IMEI", "Unknown"),
                "phone_number":  info.get("Phone Number", "Unknown"),
                "backup_date":   str(info.get("Last Backup Date", "Unknown")),
                "itunes_version": info.get("iTunes Version", "Unknown"),
            }

        # Check encryption
        manifest_plist = self.backup_path / "Manifest.plist"
        if manifest_plist.exists():
            with open(manifest_plist, "rb") as f:
                mp = plistlib.load(f)
            self._encrypted = mp.get("IsEncrypted", False)

        if self._encrypted:
            if not self.password:
                print("    [!] Backup is encrypted. Provide --password to decrypt.")
                return False
            if not HAS_DECRYPT:
                print("    [!] Install iphone-backup-decrypt: pip install iphone-backup-decrypt")
                return False
            self._decrypt_backup()
            db_path = self.decrypted_dir / "Manifest.db"
        else:
            db_path = manifest_path

        # Build file map from Manifest.db
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT fileID, domain, relativePath FROM Files")
        for row in cur.fetchall():
            key = f"{row['domain']}::{row['relativePath']}"
            # actual file path: first 2 chars = subfolder
            fid = row["fileID"]
            actual = self.backup_path / fid[:2] / fid
            if actual.exists():
                self.file_map[key] = str(actual)
        conn.close()
        return True

    # ------------------------------------------------------------------
    def _decrypt_backup(self):
        """Decrypt an encrypted backup into a temp directory."""
        self.decrypted_dir = self.backup_path.parent / (self.backup_path.name + "_decrypted")
        self.decrypted_dir.mkdir(exist_ok=True)
        backup = EncryptedBackup(backup_directory=str(self.backup_path), passphrase=self.password)
        backup.extract_all(output_folder=str(self.decrypted_dir))

    # ------------------------------------------------------------------
    def get_file(self, domain: str, relative_path: str) -> str | None:
        """Return the absolute path for a backup file, or None if missing."""
        key = f"{domain}::{relative_path}"
        return self.file_map.get(key)

    def get_files_by_domain(self, domain: str) -> dict:
        """Return all files for a given domain as {relativePath: absolutePath}."""
        result = {}
        prefix = f"{domain}::"
        for key, path in self.file_map.items():
            if key.startswith(prefix):
                rel = key[len(prefix):]
                result[rel] = path
        return result

    def get_device_info(self) -> dict:
        return self.device_info

    def is_encrypted(self) -> bool:
        return self._encrypted
